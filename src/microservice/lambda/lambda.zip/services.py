import logging

import boto3

import settings

logger = logging.getLogger()
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s: %(levelname)s: %(message)s')


class LocalstackManager:  # noqa
    @staticmethod
    def __get_credentials():
        """
        Get credentials from .env
        """
        credentials = {
            'aws_access_key_id': settings.AWS_ACCESS_KEY_ID,
            'aws_secret_access_key': settings.AWS_SECRET_ACCESS_KEY,
            'region_name': settings.REGION_NAME,
            'endpoint_url': f'{settings.HOSTNAME_EXTERNAL}:'
                            f'{settings.PORT_EXTERNAL}'
        }
        return credentials

    def _get_client(self, client_name):
        credentials = self.__get_credentials()
        client = boto3.client(service_name=client_name,
                              **credentials)
        return client

    def _get_resource(self, resource_name):
        credentials = self.__get_credentials()
        resource = boto3.resource(service_name=resource_name,
                                  **credentials)
        return resource


class LocalstackDynamoDB(LocalstackManager):
    def __init__(self):
        self.table = self.get_table()

    def get_table(self):
        resource = self._get_resource('dynamodb')
        client = self._get_client('dynamodb')

        try:
            logger.info('Trying to create table...')
            table = resource.create_table(
                TableName=settings.DYNAMODB_TABLE_NAME,
                KeySchema=[
                    {'AttributeName': 'page_id', 'KeyType': 'HASH'},
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'page_id', 'AttributeType': 'S'},
                    {'AttributeName': 'user_uuid', 'AttributeType': 'S'}
                ],
                GlobalSecondaryIndexes=[
                    {'IndexName': 'user_uuid-index',
                     'KeySchema': [
                         {'AttributeName': 'user_uuid', 'KeyType': 'HASH'},
                         {'AttributeName': 'page_id', 'KeyType': 'RANGE'}],
                     'Projection': {'ProjectionType': 'ALL'},
                     'ProvisionedThroughput': {'ReadCapacityUnits': 5,
                                               'WriteCapacityUnits': 5}
                     }
                ],
                ProvisionedThroughput={'ReadCapacityUnits': 10,
                                       'WriteCapacityUnits': 10})
            logger.info('Table successfully created.')
        except client.exceptions.ResourceInUseException:
            logger.info('Table has already exists.')
            table = resource.Table(settings.DYNAMODB_TABLE_NAME)
            logger.info('Get table by name.')
        return table

    def put_item(self, page_id: dict):
        response = self.table.put_item(Item=page_id)
        return response
